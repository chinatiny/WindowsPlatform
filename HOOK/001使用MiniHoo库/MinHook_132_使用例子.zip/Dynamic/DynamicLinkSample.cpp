#include <Windows.h>
#include "MinHook.h"

// 1. 包含静态库
#if defined _M_X64
#pragma comment(lib, "MinHook.x64.lib")
#elif defined _M_IX86
#pragma comment(lib, "MinHook.x86.lib")
#endif

template <typename T>
inline MH_STATUS MH_CreateHookApiEx(LPCWSTR pszModule, LPCSTR pszProcName, LPVOID pDetour, T** ppOriginal)
{
	// 用于HOOK的函数
    return MH_CreateHookApi(pszModule,  /* 被HOOK的API所在的模块名 */
							pszProcName,/* 被HOOK的API的函数名 */
							pDetour,    /* HOOK后的函数的地址 */
							reinterpret_cast<LPVOID*>(ppOriginal)/* [输出]原始函数的地址 */
							);
}

//2. 定义一个要HOOK的函数指针类型
typedef int (WINAPI *MESSAGEBOXW)(HWND, LPCWSTR, LPCWSTR, UINT);

//3. 定义一个函数指针变量, 用于保存原始函数
MESSAGEBOXW fpMessageBoxW = NULL;

//4. 定义一个函数, 用作HOOK后被调用的函数
int WINAPI DetourMessageBoxW(HWND hWnd, LPCWSTR lpText, LPCWSTR lpCaption, UINT uType)
{
	// 调用原始API
    return fpMessageBoxW(hWnd, L"Hooked!", lpCaption, uType);
}

int main()
{
    // 5. 初始化HOOK库
    if (MH_Initialize() != MH_OK)
    {
        return 1;
    }

    // 6. 调用HOOK函数创建一个HOOK
	//					  API所在DLL名  被HOOK的API名 HOOK后的函数        原始函数地址
    if (MH_CreateHookApiEx(L"user32", "MessageBoxW", &DetourMessageBoxW, &fpMessageBoxW) != MH_OK)
    {
        return 1;
    }

    // 7. 启用HOOK
    if (MH_EnableHook(&MessageBoxW) != MH_OK)
    {
        return 1;
    }

    // 调用原始API,HOOK后的函数将会被调用
    MessageBoxW(NULL, L"Not hooked...", L"MinHook Sample", MB_OK);

    // 8. 禁用HOOK
    if (MH_DisableHook(&MessageBoxW) != MH_OK)
    {
        return 1;
    }

    // 调用原始API,HOOK后的函数不会被调用
    MessageBoxW(NULL, L"Not hooked...", L"MinHook Sample", MB_OK);

    // 9. 卸载HOOK库
    if (MH_Uninitialize() != MH_OK)
    {
        return 1;
    }

    return 0;
}
